document.querySelector('#bt1').onclick = function(){//Sur blic du bouton ajout
    if(document.querySelector('#div1 input').value.length == 0){//Si l'entrée est vide
    alert("Entrez d'abord une tâche");//Alerter
    }
    else{//Sinon on ajoute la tâche dans un vide avec le bouton de suppression
    document.querySelector('#tasks').innerHTML += `<div class="task">
                                                    <span id="taskname">
                                                    ${document.querySelector('#div1 input').value}
                                                    </span>
                                                    <button class="delete">
                                                    Supprimer
                                                    <i class="far fa-trash-alt"></i>
                                                    </button>
                                                    </div>
                                                    `;
    var lesTaches=document.querySelectorAll(".delete");
    for(var i=0; i<lesTaches.length; i++){
    lesTaches[i].onclick = function(){//Pour les différents boutons de suppression 
    this.parentNode.remove();//on supprime la tâche concernée
    }
    }
    }
    }

  